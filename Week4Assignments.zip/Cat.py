from PIL import Image

# create an image via import
image = Image.open('/Users/owenblakers/Downloads/Week_4_Lab_Activities/Assets/cat.jpg')

# analyze the image
print(image.size)
print(image.filename)
print(image.format)

# # flip the image
image = image.transpose(Image.Transpose.ROTATE_90)
# # show the image
image.show()

# exercise
img_rotated = image.rotate(30)
img_rotated.save('/Users/owenblakers/Downloads/Week_4_Lab_Activities/Assets/img_rotated.png', 'png')